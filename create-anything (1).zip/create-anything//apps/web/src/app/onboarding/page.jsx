import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";

export default function OnboardingPage() {
  const { data: user, loading: userLoading, refetch } = useUser();
  const [loading, setLoading] = useState(false);
  const [userType, setUserType] = useState("buyer");
  const [phone, setPhone] = useState("");

  useEffect(() => {
    // Load pending profile data from localStorage
    if (typeof window !== "undefined") {
      const pendingUserType = localStorage.getItem("pendingUserType");
      if (pendingUserType && !userType) setUserType(pendingUserType);
    }
  }, [user]);

  useEffect(() => {
    // Redirect if user already has user_type set
    if (user && user.user_type && user.user_type !== "buyer") {
      if (typeof window !== "undefined") {
        window.location.href = "/";
      }
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch("/api/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_type: userType, phone }),
      });

      if (response.ok) {
        // Clear localStorage
        localStorage.removeItem("pendingUserType");

        // Refetch user data and redirect
        await refetch();
        if (typeof window !== "undefined") {
          window.location.href = "/";
        }
      } else {
        throw new Error("Error al actualizar perfil");
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
        <div className="text-blue-600">Cargando...</div>
      </div>
    );
  }

  if (!user) {
    if (typeof window !== "undefined") {
      window.location.href = "/account/signin";
    }
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4 font-inter">
      <div className="w-full max-w-2xl">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold font-poppins text-blue-600 mb-2">
              Reticks
            </h1>
            <p className="text-sm text-gray-500 mb-4">
              Reventa segura, en un clic
            </p>
            <h2 className="text-2xl font-semibold text-gray-900">
              ¡Bienvenido, {user.name}!
            </h2>
            <p className="text-gray-600 mt-2">
              Completa tu perfil para comenzar
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">
                ¿Cómo planeas usar ReTicks principalmente?
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setUserType("buyer")}
                  className={`p-6 rounded-xl border-2 text-left transition-all ${
                    userType === "buyer"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="font-semibold text-lg text-gray-900 mb-2">
                    🎫 Comprar entradas
                  </div>
                  <div className="text-sm text-gray-500">
                    Busco entradas para eventos, conciertos, shows y más
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setUserType("seller")}
                  className={`p-6 rounded-xl border-2 text-left transition-all ${
                    userType === "seller"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="font-semibold text-lg text-gray-900 mb-2">
                    💰 Vender entradas
                  </div>
                  <div className="text-sm text-gray-500">
                    Tengo entradas que quiero vender de forma segura
                  </div>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Teléfono (opcional)
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="+56 9 1234 5678"
              />
              <p className="text-sm text-gray-500 mt-1">
                Te ayudará a verificar tu cuenta y recibir notificaciones
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="font-semibold text-blue-900 mb-2">
                {userType === "buyer"
                  ? "Como comprador, podrás:"
                  : "Como vendedor, podrás:"}
              </h3>
              <ul className="text-sm text-blue-700 space-y-1">
                {userType === "buyer" ? (
                  <>
                    <li>• Buscar entradas por evento, precio y ubicación</li>
                    <li>• Participar en subastas en tiempo real</li>
                    <li>• Comprar con garantía de devolución</li>
                    <li>• Recibir entradas validadas</li>
                  </>
                ) : (
                  <>
                    <li>• Publicar entradas con precios fijos o subastas</li>
                    <li>• Recibir pagos seguros con sistema de escrow</li>
                    <li>• Gestionar ventas desde tu panel</li>
                    <li>• Obtener reseñas de compradores</li>
                  </>
                )}
              </ul>
            </div>

            <div className="text-center">
              <button
                type="submit"
                disabled={loading}
                className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-8 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Configurando..." : "Completar registro"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
