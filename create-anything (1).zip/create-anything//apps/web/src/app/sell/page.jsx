import { useEffect } from "react";
import useUser from "@/utils/useUser";
import { useSellTicket } from "@/hooks/useSellTicket";
import { formatDate } from "@/utils/formatDate";
import { SellTicketsHeader } from "@/components/SellTickets/SellTicketsHeader";
import { ProgressIndicator } from "@/components/SellTickets/ProgressIndicator";
import { StepOne } from "@/components/SellTickets/StepOne";
import { StepTwo } from "@/components/SellTickets/StepTwo";
import { StepThree } from "@/components/SellTickets/StepThree";
import { NavigationButtons } from "@/components/SellTickets/NavigationButtons";

export default function SellTicketsPage() {
  const { data: user, loading: userLoading } = useUser();
  const {
    events,
    eventsLoading,
    step,
    formData,
    errors,
    uploading,
    submitting,
    selectedEvent,
    handleInputChange,
    nextStep,
    prevStep,
    handleSubmit,
  } = useSellTicket();

  useEffect(() => {
    if (!userLoading && !user) {
      window.location.href = "/account/signin";
    }
  }, [user, userLoading]);

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-blue-600">Cargando...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 font-inter">
      <SellTicketsHeader userName={user.name} />

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <ProgressIndicator step={step} />

          {/* Form Content */}
          <div className="p-8">
            {errors.general && (
              <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
                {errors.general}
              </div>
            )}

            {step === 1 && (
              <StepOne
                formData={formData}
                errors={errors}
                events={events}
                eventsLoading={eventsLoading}
                selectedEvent={selectedEvent}
                handleInputChange={handleInputChange}
                formatDate={formatDate}
              />
            )}

            {step === 2 && (
              <StepTwo
                formData={formData}
                errors={errors}
                handleInputChange={handleInputChange}
              />
            )}

            {step === 3 && (
              <StepThree
                formData={formData}
                selectedEvent={selectedEvent}
                formatDate={formatDate}
              />
            )}

            <NavigationButtons
              step={step}
              submitting={submitting}
              uploading={uploading}
              onPrev={prevStep}
              onNext={nextStep}
              onSubmit={handleSubmit}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
