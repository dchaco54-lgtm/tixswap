import useAuth from "@/utils/useAuth";

export default function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4 font-inter">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-poppins text-blue-600 mb-2">
              Reticks
            </h1>
            <p className="text-sm text-gray-500 mb-4">
              Reventa segura, en un clic
            </p>
            <h2 className="text-2xl font-semibold text-gray-900">
              ¿Cerrar sesión?
            </h2>
            <p className="text-gray-600 mt-2">
              ¿Estás seguro de que quieres cerrar tu sesión en Reticks?
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={handleSignOut}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors"
            >
              Sí, cerrar sesión
            </button>

            <a
              href="/"
              className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 px-4 rounded-lg transition-colors block text-center"
            >
              Cancelar
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
