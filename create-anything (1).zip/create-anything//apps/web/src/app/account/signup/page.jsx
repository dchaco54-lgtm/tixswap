"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";
import { Eye, EyeOff, User, Mail, Phone, Shield, Check } from "lucide-react";

export default function SignUpPage() {
  const { signUpWithCredentials } = useAuth();
  const [formData, setFormData] = useState({
    name: "",
    rut: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    user_type: "user",
    acceptTerms: false,
  });
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  // Validar formato de RUT chileno
  const validateRUT = (rut) => {
    // Remover puntos y guión
    const cleanRUT = rut.replace(/\./g, "").replace(/-/g, "");
    if (cleanRUT.length < 8 || cleanRUT.length > 9) return false;

    const body = cleanRUT.slice(0, -1);
    const dv = cleanRUT.slice(-1).toLowerCase();

    // Algoritmo para calcular dígito verificador
    let sum = 0;
    let multiplier = 2;

    for (let i = body.length - 1; i >= 0; i--) {
      sum += parseInt(body[i]) * multiplier;
      multiplier = multiplier === 7 ? 2 : multiplier + 1;
    }

    const remainder = sum % 11;
    const expectedDV =
      remainder === 0
        ? "0"
        : remainder === 1
          ? "k"
          : (11 - remainder).toString();

    return dv === expectedDV;
  };

  // Formatear RUT mientras se escribe
  const formatRUT = (value) => {
    // Remover todo excepto números y k
    const clean = value.replace(/[^\d|k|K]/g, "").toUpperCase();

    if (clean.length <= 1) return clean;

    // Separar cuerpo y dígito verificador
    const body = clean.slice(0, -1);
    const dv = clean.slice(-1);

    // Formatear cuerpo con puntos
    const formattedBody = body.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    return `${formattedBody}-${dv}`;
  };

  // Validar teléfono chileno
  const validatePhone = (phone) => {
    const phoneRegex = /^\+56\d{8,9}$/;
    return phoneRegex.test(phone);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;

    let processedValue = value;

    // Formatear RUT en tiempo real
    if (name === "rut") {
      processedValue = formatRUT(value);
    }

    // Formatear teléfono
    if (name === "phone" && !value.startsWith("+56")) {
      processedValue = "+56" + value.replace(/^\+56/, "");
    }

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : processedValue,
    }));

    // Limpiar errores cuando se modifica el campo
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "El nombre es obligatorio";
    }

    if (!formData.rut.trim()) {
      newErrors.rut = "El RUT es obligatorio";
    } else if (!validateRUT(formData.rut)) {
      newErrors.rut = "RUT inválido";
    }

    if (!formData.email.trim()) {
      newErrors.email = "El email es obligatorio";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email inválido";
    }

    if (!formData.phone.trim()) {
      newErrors.phone = "El teléfono es obligatorio";
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = "Teléfono debe tener formato +56XXXXXXXX";
    }

    if (!formData.password) {
      newErrors.password = "La contraseña es obligatoria";
    } else if (formData.password.length < 6) {
      newErrors.password = "La contraseña debe tener al menos 6 caracteres";
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Las contraseñas no coinciden";
    }

    if (!formData.acceptTerms) {
      newErrors.acceptTerms = "Debes aceptar los términos y condiciones";
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);
    setErrors({});

    try {
      await signUpWithCredentials({
        email: formData.email,
        password: formData.password,
        name: formData.name,
        rut: formData.rut.replace(/\./g, "").replace(/-/g, ""), // Guardar RUT sin formato
        phone: formData.phone,
        user_type: formData.user_type,
        callbackUrl: "/",
        redirect: true,
      });
    } catch (error) {
      console.error("Error en registro:", error);

      if (error.message?.includes("rut")) {
        setErrors({ rut: "Este RUT ya está registrado" });
      } else if (error.message?.includes("email")) {
        setErrors({ email: "Este email ya está registrado" });
      } else {
        setErrors({ general: "Error al crear la cuenta. Inténtalo de nuevo." });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 sm:px-6 lg:px-8 font-inter">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex justify-center items-center space-x-3 mb-6">
            <img
              src="https://ucarecdn.com/e643de87-2123-4693-8a03-6e49f697b8ec/-/format/auto/"
              alt="TixSwap Logo"
              className="h-12 w-auto"
            />
            <h1 className="text-3xl font-bold font-poppins text-blue-600">
              TixSwap
            </h1>
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Crear cuenta</h2>
          <p className="mt-2 text-sm text-gray-600">
            Únete al marketplace más seguro de Chile
          </p>
        </div>

        {/* Formulario */}
        <form
          className="space-y-6 bg-white p-8 rounded-xl shadow-sm"
          onSubmit={handleSubmit}
        >
          {errors.general && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-700 text-sm">{errors.general}</p>
            </div>
          )}

          {/* Nombre completo */}
          <div>
            <label
              htmlFor="name"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Nombre completo
            </label>
            <div className="relative">
              <User
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="Tu nombre completo"
                required
              />
            </div>
            {errors.name && (
              <p className="mt-1 text-sm text-red-600">{errors.name}</p>
            )}
          </div>

          {/* RUT */}
          <div>
            <label
              htmlFor="rut"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              RUT
            </label>
            <div className="relative">
              <Shield
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
              <input
                id="rut"
                name="rut"
                type="text"
                value={formData.rut}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="12.345.678-9"
                maxLength="12"
                required
              />
            </div>
            {errors.rut && (
              <p className="mt-1 text-sm text-red-600">{errors.rut}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Correo electrónico
            </label>
            <div className="relative">
              <Mail
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="tu@email.com"
                required
              />
            </div>
            {errors.email && (
              <p className="mt-1 text-sm text-red-600">{errors.email}</p>
            )}
          </div>

          {/* Teléfono */}
          <div>
            <label
              htmlFor="phone"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Teléfono (para validación SMS)
            </label>
            <div className="relative">
              <Phone
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="+56987654321"
                required
              />
            </div>
            {errors.phone && (
              <p className="mt-1 text-sm text-red-600">{errors.phone}</p>
            )}
          </div>

          {/* Tipo de usuario (estadístico) */}
          <div>
            <label
              htmlFor="user_type"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              ¿Qué tipo de usuario eres? (solo estadístico)
            </label>
            <select
              id="user_type"
              name="user_type"
              value={formData.user_type}
              onChange={handleInputChange}
              className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            >
              <option value="user">Usuario general</option>
              <option value="frequent_buyer">Comprador frecuente</option>
              <option value="occasional_seller">Vendedor ocasional</option>
              <option value="promoter">Promotor de eventos</option>
            </select>
            <p className="mt-1 text-xs text-gray-500">
              Esto no limita tus funciones, solo nos ayuda con estadísticas
            </p>
          </div>

          {/* Contraseña */}
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Contraseña
            </label>
            <div className="relative">
              <input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                value={formData.password}
                onChange={handleInputChange}
                className="w-full pr-10 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="••••••••"
                minLength={6}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {errors.password && (
              <p className="mt-1 text-sm text-red-600">{errors.password}</p>
            )}
          </div>

          {/* Confirmar contraseña */}
          <div>
            <label
              htmlFor="confirmPassword"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Confirmar contraseña
            </label>
            <div className="relative">
              <input
                id="confirmPassword"
                name="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                value={formData.confirmPassword}
                onChange={handleInputChange}
                className="w-full pr-10 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {errors.confirmPassword && (
              <p className="mt-1 text-sm text-red-600">
                {errors.confirmPassword}
              </p>
            )}
          </div>

          {/* Términos y condiciones */}
          <div>
            <div className="flex items-start space-x-3">
              <input
                id="acceptTerms"
                name="acceptTerms"
                type="checkbox"
                checked={formData.acceptTerms}
                onChange={handleInputChange}
                className="mt-1 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                required
              />
              <div className="text-sm">
                <label htmlFor="acceptTerms" className="text-gray-700">
                  Acepto los{" "}
                  <a
                    href="/terms"
                    className="text-blue-600 hover:text-blue-700 underline"
                  >
                    términos y condiciones
                  </a>{" "}
                  y la{" "}
                  <a
                    href="/privacy"
                    className="text-blue-600 hover:text-blue-700 underline"
                  >
                    política de privacidad
                  </a>
                </label>
              </div>
            </div>
            {errors.acceptTerms && (
              <p className="mt-1 text-sm text-red-600">{errors.acceptTerms}</p>
            )}
          </div>

          {/* Botón de registro */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
          >
            {loading ? "Creando cuenta..." : "Crear cuenta"}
          </button>

          {/* Link a login */}
          <div className="text-center">
            <span className="text-sm text-gray-600">
              ¿Ya tienes cuenta?{" "}
              <a
                href={`/account/signin${typeof window !== "undefined" ? window.location.search : ""}`}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                Inicia sesión
              </a>
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}
