import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");
    const category = searchParams.get("category");
    const limit = parseInt(searchParams.get("limit") || "10");
    const offset = parseInt(searchParams.get("offset") || "0");

    let whereConditions = [];
    let values = [];
    let valueIndex = 1;

    // Only show active events that haven't passed
    whereConditions.push(`status = $${valueIndex} AND event_date >= NOW()`);
    values.push("active");
    valueIndex++;

    if (search) {
      whereConditions.push(`(
        LOWER(title) LIKE LOWER($${valueIndex}) OR 
        LOWER(venue) LIKE LOWER($${valueIndex + 1}) OR 
        LOWER(description) LIKE LOWER($${valueIndex + 2})
      )`);
      const searchPattern = `%${search}%`;
      values.push(searchPattern, searchPattern, searchPattern);
      valueIndex += 3;
    }

    if (category) {
      whereConditions.push(`LOWER(category) = LOWER($${valueIndex})`);
      values.push(category);
      valueIndex++;
    }

    const whereClause =
      whereConditions.length > 0
        ? `WHERE ${whereConditions.join(" AND ")}`
        : "";

    const query = `
      SELECT id, title, description, venue, event_date, category, image_url, status, created_at
      FROM events 
      ${whereClause}
      ORDER BY event_date ASC 
      LIMIT $${valueIndex} OFFSET $${valueIndex + 1}
    `;

    values.push(limit, offset);

    const events = await sql(query, values);

    // Get total count for pagination
    const countQuery = `
      SELECT COUNT(*) as total 
      FROM events 
      ${whereClause}
    `;

    const countResult = await sql(countQuery, values.slice(0, -2)); // Remove limit and offset from count query
    const total = parseInt(countResult[0]?.total || 0);

    return Response.json({
      events: events || [],
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    });
  } catch (err) {
    console.error("GET /api/events error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { title, description, venue, event_date, category, image_url } = body;

    // Validation
    if (!title || !venue || !event_date) {
      return Response.json(
        { error: "Title, venue, and event_date are required" },
        { status: 400 },
      );
    }

    // Check if event_date is in the future
    const eventDate = new Date(event_date);
    if (eventDate <= new Date()) {
      return Response.json(
        { error: "Event date must be in the future" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO events (title, description, venue, event_date, category, image_url)
      VALUES (${title}, ${description}, ${venue}, ${event_date}, ${category}, ${image_url})
      RETURNING id, title, description, venue, event_date, category, image_url, status, created_at
    `;

    return Response.json({ event: result[0] }, { status: 201 });
  } catch (err) {
    console.error("POST /api/events error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
