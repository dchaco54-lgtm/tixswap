import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const sellerId = searchParams.get("seller_id");
    const status = searchParams.get("status") || "available";
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");

    let whereConditions = [];
    let values = [];
    let valueIndex = 1;

    if (sellerId) {
      whereConditions.push(`t.seller_id = $${valueIndex}`);
      values.push(sellerId);
      valueIndex++;
    }

    if (status) {
      whereConditions.push(`t.status = $${valueIndex}`);
      values.push(status);
      valueIndex++;
    }

    const whereClause =
      whereConditions.length > 0
        ? `WHERE ${whereConditions.join(" AND ")}`
        : "";

    const query = `
      SELECT 
        t.id, t.event_id, t.seller_id, t.title, t.description, t.sector, 
        t.row_number, t.seat_number, t.price, t.original_price, t.ticket_type,
        t.ticket_file_url, t.is_auction, t.auto_auction, t.auction_end_time, t.status,
        t.validation_status, t.created_at, t.updated_at,
        e.title as event_title, e.event_date, e.venue,
        u.name as seller_name, u.verified as seller_verified
      FROM tickets t
      LEFT JOIN events e ON t.event_id = e.id
      LEFT JOIN auth_users u ON t.seller_id = u.id
      ${whereClause}
      ORDER BY t.created_at DESC
      LIMIT $${valueIndex} OFFSET $${valueIndex + 1}
    `;

    values.push(limit, offset);

    const tickets = await sql(query, values);

    // Get total count for pagination
    const countQuery = `
      SELECT COUNT(*) as total 
      FROM tickets t
      ${whereClause}
    `;

    const countResult = await sql(countQuery, values.slice(0, -2));
    const total = parseInt(countResult[0]?.total || 0);

    return Response.json({
      tickets: tickets || [],
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    });
  } catch (err) {
    console.error("GET /api/tickets error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      event_id,
      title,
      description,
      sector,
      row_number,
      seat_number,
      price,
      original_price,
      ticket_type,
      ticket_file_url,
      qr_code,
      is_auction,
      auto_auction,
      auction_end_time,
    } = body;

    // Validation
    if (!event_id || !title || !price || price <= 0) {
      return Response.json(
        { error: "Event ID, title, and valid price are required" },
        { status: 400 },
      );
    }

    // Verify event exists and is active
    const eventCheck = await sql`
      SELECT id, event_date FROM events 
      WHERE id = ${event_id} AND status = 'active'
      LIMIT 1
    `;

    if (!eventCheck || eventCheck.length === 0) {
      return Response.json(
        { error: "Event not found or inactive" },
        { status: 400 },
      );
    }

    // Check if event is in the future
    const eventDate = new Date(eventCheck[0].event_date);
    if (eventDate <= new Date()) {
      return Response.json(
        { error: "Cannot sell tickets for past events" },
        { status: 400 },
      );
    }

    // Validate auction end time if it's an auction
    if (is_auction && auction_end_time) {
      const auctionEnd = new Date(auction_end_time);
      if (auctionEnd <= new Date()) {
        return Response.json(
          { error: "Auction end time must be in the future" },
          { status: 400 },
        );
      }
      if (auctionEnd >= eventDate) {
        return Response.json(
          { error: "Auction must end before the event date" },
          { status: 400 },
        );
      }
    }

    // Validate ticket file or QR code based on type
    if (ticket_type === "qr" && (!qr_code || qr_code.trim().length === 0)) {
      return Response.json(
        { error: "QR code is required for QR ticket type" },
        { status: 400 },
      );
    }

    if (
      (ticket_type === "pdf" || ticket_type === "image") &&
      !ticket_file_url
    ) {
      return Response.json(
        { error: "File upload is required for PDF/image ticket types" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO tickets (
        event_id, seller_id, title, description, sector, row_number, seat_number,
        price, original_price, ticket_type, ticket_file_url, qr_code,
        is_auction, auto_auction, auction_end_time
      )
      VALUES (
        ${event_id}, ${session.user.id}, ${title}, ${description || null}, 
        ${sector || null}, ${row_number || null}, ${seat_number || null},
        ${price}, ${original_price || null}, ${ticket_type}, 
        ${ticket_file_url || null}, ${qr_code || null},
        ${is_auction || false}, ${auto_auction || false}, ${auction_end_time || null}
      )
      RETURNING 
        id, event_id, seller_id, title, description, sector, row_number, seat_number,
        price, original_price, ticket_type, ticket_file_url, qr_code,
        is_auction, auto_auction, auction_end_time, status, validation_status, created_at
    `;

    return Response.json({ ticket: result[0] }, { status: 201 });
  } catch (err) {
    console.error("POST /api/tickets error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
