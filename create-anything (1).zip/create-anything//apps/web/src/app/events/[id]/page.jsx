import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Calendar,
  MapPin,
  Users,
  Clock,
  Shield,
  DollarSign,
  Filter,
} from "lucide-react";

export default function EventDetailPage({ params }) {
  const { data: user } = useUser();
  const [event, setEvent] = useState(null);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [ticketsLoading, setTicketsLoading] = useState(true);
  const [priceFilter, setPriceFilter] = useState("all");
  const [sortBy, setSortBy] = useState("price_asc");

  useEffect(() => {
    if (params?.id) {
      fetchEvent();
      fetchTickets();
    }
  }, [params?.id]);

  const fetchEvent = async () => {
    try {
      const response = await fetch(`/api/events/${params.id}`);
      if (response.ok) {
        const data = await response.json();
        setEvent(data.event);
      } else {
        console.error("Event not found");
      }
    } catch (error) {
      console.error("Error fetching event:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTickets = async () => {
    try {
      const response = await fetch(`/api/events/${params.id}/tickets`);
      if (response.ok) {
        const data = await response.json();
        setTickets(data.tickets || []);
      }
    } catch (error) {
      console.error("Error fetching tickets:", error);
    } finally {
      setTicketsLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("es-CL", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
    }).format(price);
  };

  const getFilteredAndSortedTickets = () => {
    let filtered = tickets.filter((ticket) => ticket.status === "available");

    // Price filter
    if (priceFilter === "under_50k") {
      filtered = filtered.filter((ticket) => ticket.price < 50000);
    } else if (priceFilter === "50k_100k") {
      filtered = filtered.filter(
        (ticket) => ticket.price >= 50000 && ticket.price < 100000,
      );
    } else if (priceFilter === "over_100k") {
      filtered = filtered.filter((ticket) => ticket.price >= 100000);
    }

    // Sorting
    if (sortBy === "price_asc") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price_desc") {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortBy === "sector") {
      filtered.sort((a, b) => (a.sector || "").localeCompare(b.sector || ""));
    }

    return filtered;
  };

  const handleBuyTicket = (ticketId) => {
    if (!user) {
      window.location.href = "/account/signin";
      return;
    }
    window.location.href = `/checkout/${ticketId}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-blue-600">Cargando evento...</div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Evento no encontrado
          </h2>
          <a href="/" className="text-blue-600 hover:text-blue-700">
            Volver al inicio
          </a>
        </div>
      </div>
    );
  }

  const filteredTickets = getFilteredAndSortedTickets();

  return (
    <div className="min-h-screen bg-gray-50 font-inter">
      {/* Header */}
      <header className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <a href="/" className="flex items-center space-x-3">
                <img
                  src="https://ucarecdn.com/e643de87-2123-4693-8a03-6e49f697b8ec/-/format/auto/"
                  alt="TixSwap Logo"
                  className="h-10 w-auto"
                />
                <div>
                  <h1 className="text-2xl font-bold font-poppins text-blue-600">
                    TixSwap
                  </h1>
                  <span className="text-xs text-gray-500 font-inter hidden sm:block">
                    Reventa segura, en un clic
                  </span>
                </div>
              </a>
            </div>

            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-600">
                    Hola, {user.name}
                  </span>
                  <a
                    href="/dashboard"
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Mi Panel
                  </a>
                </div>
              ) : (
                <div className="flex items-center space-x-3">
                  <a
                    href="/account/signin"
                    className="text-gray-600 hover:text-blue-600 transition-colors text-sm font-medium"
                  >
                    Iniciar sesión
                  </a>
                  <a
                    href="/account/signup"
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Registrarse
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Event Hero */}
      <section className="bg-gradient-to-br from-blue-400 to-purple-500 py-16 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center bg-blue-600/20 rounded-full px-3 py-1 text-sm mb-4">
                {event.category}
              </div>
              <h1 className="text-4xl font-bold font-poppins mb-4">
                {event.title}
              </h1>
              <p className="text-blue-100 text-lg mb-6">{event.description}</p>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <Calendar className="text-blue-200" size={20} />
                  <div>
                    <div className="text-sm text-blue-200">Fecha</div>
                    <div className="font-semibold">
                      {formatDate(event.event_date)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <MapPin className="text-blue-200" size={20} />
                  <div>
                    <div className="text-sm text-blue-200">Lugar</div>
                    <div className="font-semibold">{event.venue}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:text-right">
              <div className="bg-white/10 backdrop-blur rounded-2xl p-6">
                <h3 className="text-lg font-semibold mb-2">
                  Entradas disponibles
                </h3>
                <div className="text-3xl font-bold">
                  {filteredTickets.length}
                </div>
                <p className="text-blue-200 text-sm">
                  desde{" "}
                  {filteredTickets.length > 0
                    ? formatPrice(
                        Math.min(...filteredTickets.map((t) => t.price)),
                      )
                    : "--"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tickets Section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar */}
            <div className="lg:w-64 space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                  <Filter size={18} className="mr-2" />
                  Filtros
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rango de precio
                    </label>
                    <select
                      value={priceFilter}
                      onChange={(e) => setPriceFilter(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="all">Todos los precios</option>
                      <option value="under_50k">Hasta $50.000</option>
                      <option value="50k_100k">$50.000 - $100.000</option>
                      <option value="over_100k">Más de $100.000</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ordenar por
                    </label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="price_asc">Precio: menor a mayor</option>
                      <option value="price_desc">Precio: mayor a menor</option>
                      <option value="sector">Sector</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Security Info */}
              <div className="bg-blue-50 rounded-xl p-6">
                <h4 className="font-semibold text-blue-900 mb-3 flex items-center">
                  <Shield size={18} className="mr-2" />
                  Compra segura
                </h4>
                <ul className="text-sm text-blue-700 space-y-2">
                  <li>• Pago protegido con escrow</li>
                  <li>• Validación de entradas</li>
                  <li>• Garantía de devolución</li>
                  <li>• Chat directo con vendedor</li>
                  <li>• Soporte 24/7</li>
                </ul>
              </div>
            </div>

            {/* Tickets List */}
            <div className="flex-1">
              {ticketsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl shadow-sm p-6 animate-pulse"
                    >
                      <div className="flex justify-between items-center">
                        <div className="space-y-2 flex-1">
                          <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                          <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                        </div>
                        <div className="h-10 w-24 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredTickets.length === 0 ? (
                <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                  <div className="text-gray-400 mb-4">
                    <Users size={48} className="mx-auto" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    No hay entradas disponibles
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {tickets.length === 0
                      ? "Aún no hay entradas publicadas para este evento."
                      : "No hay entradas que coincidan con tus filtros."}
                  </p>
                  <a
                    href="/sell"
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-block"
                  >
                    ¿Tienes entradas? Véndelas aquí
                  </a>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredTickets.map((ticket) => (
                    <div
                      key={ticket.id}
                      className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="text-sm font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded">
                                {ticket.sector || "General"}
                              </span>
                              {ticket.is_auction && (
                                <span className="text-sm font-medium text-orange-600 bg-orange-100 px-2 py-1 rounded flex items-center">
                                  <Clock size={12} className="mr-1" />
                                  Subasta
                                </span>
                              )}
                              <span className="text-sm font-medium text-green-600 bg-green-100 px-2 py-1 rounded">
                                Verificada
                              </span>
                            </div>

                            <h3 className="font-semibold text-gray-900 mb-2">
                              {ticket.title}
                            </h3>

                            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                              {ticket.row_number && (
                                <span>Fila: {ticket.row_number}</span>
                              )}
                              {ticket.seat_number && (
                                <span>Asiento: {ticket.seat_number}</span>
                              )}
                            </div>

                            <p className="text-sm text-gray-600 mb-3">
                              {ticket.description}
                            </p>

                            <div className="flex items-center text-sm text-gray-500">
                              <span>Vendedor verificado</span>
                              <span className="ml-2">★★★★★</span>
                            </div>
                          </div>

                          <div className="lg:text-right">
                            <div className="mb-3">
                              <div className="text-2xl font-bold text-gray-900">
                                {formatPrice(ticket.price)}
                              </div>
                              {ticket.original_price &&
                                ticket.original_price !== ticket.price && (
                                  <div className="text-sm text-gray-500 line-through">
                                    {formatPrice(ticket.original_price)}
                                  </div>
                                )}
                              <div className="text-xs text-gray-500 mt-1">
                                + 2% comisión TixSwap
                              </div>
                            </div>

                            <button
                              onClick={() => handleBuyTicket(ticket.id)}
                              className="w-full lg:w-auto bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center"
                            >
                              <DollarSign size={18} className="mr-2" />
                              {ticket.is_auction ? "Pujar" : "Comprar"}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
