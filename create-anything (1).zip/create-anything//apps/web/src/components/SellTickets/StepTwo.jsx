import {
  Upload,
  FileText,
  Camera,
  X,
  MessageCircle,
  Check,
} from "lucide-react";

export function StepTwo({ formData, errors, handleInputChange }) {
  const isNominada = formData.is_nominada || false;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">
        Información de la entrada
      </h2>

      {/* Checkbox: Entrada nominada */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <input
            type="checkbox"
            id="is_nominada"
            checked={isNominada}
            onChange={(e) => handleInputChange("is_nominada", e.target.checked)}
            className="mt-1 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
          />
          <div>
            <label
              htmlFor="is_nominada"
              className="text-sm font-medium text-gray-900"
            >
              Esta entrada es nominada
            </label>
            <p className="text-sm text-gray-600 mt-1">
              {isNominada
                ? "✓ Se habilitará el chat con el comprador para coordinar el cambio de nombre"
                : "Las entradas no nominadas requieren archivo PDF obligatorio"}
            </p>
          </div>
        </div>

        {isNominada && (
          <div className="mt-3 flex items-center space-x-2 text-sm text-blue-700">
            <MessageCircle size={16} />
            <span>Chat comprador-vendedor habilitado</span>
          </div>
        )}
      </div>

      {/* Archivo según tipo de entrada */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {isNominada ? "Imagen QR de la entrada" : "Archivo PDF de la entrada"}{" "}
          *
        </label>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 mb-3">
          <p className="text-sm text-gray-600 flex items-center">
            {isNominada ? (
              <>
                <Camera size={16} className="mr-2 text-blue-600" />
                Sube una imagen (JPG, PNG) del código QR de tu entrada nominada
              </>
            ) : (
              <>
                <FileText size={16} className="mr-2 text-red-600" />
                Sube el archivo PDF completo de tu entrada (obligatorio para
                entradas no nominadas)
              </>
            )}
          </p>
        </div>

        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
            errors.ticket_file
              ? "border-red-300 bg-red-50"
              : "border-gray-300 hover:border-blue-400"
          }`}
        >
          <Upload size={48} className="mx-auto text-gray-400 mb-4" />
          <div className="space-y-2">
            <p className="text-sm text-gray-600">
              Arrastra tu {isNominada ? "imagen" : "archivo PDF"} aquí o haz
              clic para seleccionar
            </p>
            <input
              type="file"
              accept={isNominada ? "image/*" : ".pdf"}
              onChange={(e) =>
                handleInputChange("ticket_file", e.target.files[0])
              }
              className="hidden"
              id="ticket-file"
            />
            <label
              htmlFor="ticket-file"
              className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer"
            >
              Seleccionar {isNominada ? "imagen" : "archivo PDF"}
            </label>
            <p className="text-xs text-gray-500">
              {isNominada
                ? "JPG, PNG hasta 10MB"
                : "Solo archivos PDF hasta 10MB"}
            </p>
          </div>
          {formData.ticket_file && (
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-green-700 flex items-center">
                  <Check size={16} className="mr-2" />
                  {formData.ticket_file.name}
                </span>
                <button
                  type="button"
                  onClick={() => handleInputChange("ticket_file", null)}
                  className="text-red-500 hover:text-red-700"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          )}
        </div>
        {errors.ticket_file && (
          <p className="mt-1 text-sm text-red-600">{errors.ticket_file}</p>
        )}
      </div>

      {/* Checkbox: Subasta automática */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <input
            type="checkbox"
            id="auto_auction"
            checked={formData.auto_auction || false}
            onChange={(e) =>
              handleInputChange("auto_auction", e.target.checked)
            }
            className="mt-1 h-4 w-4 text-yellow-600 border-gray-300 rounded focus:ring-yellow-500"
          />
          <div>
            <label
              htmlFor="auto_auction"
              className="text-sm font-medium text-gray-900"
            >
              Activar subasta automática de emergencia
            </label>
            <p className="text-sm text-gray-600 mt-1">
              Si no se vende, se pondrá automáticamente en subasta 2 horas antes
              del evento. La subasta se cierra 2 horas antes del evento.
            </p>
          </div>
        </div>
      </div>

      {/* Información adicional */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-2">
          Información importante:
        </h3>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• Todas las entradas son revisadas por nuestro equipo</li>
          <li>• TixSwap cobra una comisión del 3% al vendedor</li>
          <li>
            • Los fondos se liberan cuando el comprador confirma la entrada
          </li>
          {isNominada && (
            <li>
              • Para entradas nominadas, debes coordinar el cambio de nombre con
              el comprador
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
