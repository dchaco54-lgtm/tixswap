export function StepThree({ formData, selectedEvent, formatDate }) {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">
        Confirmar publicación
      </h2>

      <div className="bg-gray-50 rounded-lg p-6 space-y-4">
        <h3 className="font-semibold text-gray-900">Resumen de tu entrada</h3>

        {selectedEvent && (
          <div>
            <span className="text-sm font-medium text-gray-500">Evento:</span>
            <div className="text-gray-900">{selectedEvent.title}</div>
            <div className="text-sm text-gray-600">
              {formatDate(selectedEvent.event_date)} • {selectedEvent.venue}
            </div>
          </div>
        )}

        <div>
          <span className="text-sm font-medium text-gray-500">Entrada:</span>
          <div className="text-gray-900">{formData.title}</div>
          {formData.description && (
            <div className="text-sm text-gray-600">{formData.description}</div>
          )}
        </div>

        {(formData.sector || formData.row_number || formData.seat_number) && (
          <div>
            <span className="text-sm font-medium text-gray-500">
              Ubicación:
            </span>
            <div className="text-gray-900">
              {[
                formData.sector,
                formData.row_number && `Fila ${formData.row_number}`,
                formData.seat_number && `Asiento ${formData.seat_number}`,
              ]
                .filter(Boolean)
                .join(" • ")}
            </div>
          </div>
        )}

        <div>
          <span className="text-sm font-medium text-gray-500">Precio:</span>
          <div className="text-2xl font-bold text-green-600">
            ${parseFloat(formData.price || 0).toLocaleString("es-CL")}
          </div>
          {formData.original_price && (
            <div className="text-sm text-gray-500 line-through">
              ${parseFloat(formData.original_price).toLocaleString("es-CL")}
            </div>
          )}
        </div>

        <div>
          <span className="text-sm font-medium text-gray-500">
            Tipo de venta:
          </span>
          <div className="text-gray-900">
            {formData.is_auction ? "Subasta" : "Precio fijo"}
            {formData.is_auction && formData.auction_end_time && (
              <span className="text-sm text-gray-600 ml-2">
                (hasta{" "}
                {new Date(formData.auction_end_time).toLocaleDateString(
                  "es-CL",
                )}
                )
              </span>
            )}
            {formData.auto_auction && !formData.is_auction && (
              <span className="text-sm text-orange-600 ml-2">
                (+ Subasta automática de emergencia)
              </span>
            )}
          </div>
        </div>

        <div>
          <span className="text-sm font-medium text-gray-500">Archivo:</span>
          <div className="text-gray-900">
            {formData.ticket_type === "qr"
              ? "Código QR"
              : formData.ticket_file
                ? formData.ticket_file.name
                : "No seleccionado"}
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">
          Términos y condiciones
        </h4>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• ReTicks retiene una comisión del 5% sobre la venta</li>
          <li>
            • Los fondos se liberan cuando el comprador confirme la validez
          </li>
          <li>• Debes proporcionar entradas válidas y auténticas</li>
          <li>• En caso de disputa, se requiere evidencia de autenticidad</li>
        </ul>
      </div>
    </div>
  );
}
