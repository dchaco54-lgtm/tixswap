export function ProgressIndicator({ step }) {
  return (
    <div className="bg-gradient-to-r from-blue-500 to-purple-600 px-8 py-6">
      <h1 className="text-2xl font-bold text-white mb-4">Vender entrada</h1>
      <div className="flex items-center space-x-4">
        <div
          className={`flex items-center space-x-2 ${step >= 1 ? "text-white" : "text-blue-200"}`}
        >
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-white text-blue-600" : "bg-blue-400"}`}
          >
            1
          </div>
          <span>Detalles</span>
        </div>
        <div className="flex-1 h-0.5 bg-blue-300"></div>
        <div
          className={`flex items-center space-x-2 ${step >= 2 ? "text-white" : "text-blue-200"}`}
        >
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-white text-blue-600" : "bg-blue-400"}`}
          >
            2
          </div>
          <span>Archivo</span>
        </div>
        <div className="flex-1 h-0.5 bg-blue-300"></div>
        <div
          className={`flex items-center space-x-2 ${step >= 3 ? "text-white" : "text-blue-200"}`}
        >
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? "bg-white text-blue-600" : "bg-blue-400"}`}
          >
            3
          </div>
          <span>Confirmar</span>
        </div>
      </div>
    </div>
  );
}
