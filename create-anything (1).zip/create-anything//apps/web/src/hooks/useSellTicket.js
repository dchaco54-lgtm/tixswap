import { useState, useEffect } from "react";

export function useSellTicket() {
  const [events, setEvents] = useState([]);
  const [eventsLoading, setEventsLoading] = useState(true);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    event_id: "",
    title: "",
    description: "",
    sector: "",
    row_number: "",
    seat_number: "",
    price: "",
    original_price: "",
    ticket_type: "pdf",
    is_auction: false,
    auto_auction: false,
    auction_end_time: "",
    ticket_file: null,
    qr_code: "",
  });
  const [errors, setErrors] = useState({});
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await fetch("/api/events?limit=50");
      if (response.ok) {
        const data = await response.json();
        setEvents(data.events || []);
      }
    } catch (error) {
      console.error("Error fetching events:", error);
    } finally {
      setEventsLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: null }));
    }
  };

  const handleFileUpload = async (file) => {
    if (!file) return null;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/_create/api/upload/", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const data = await response.json();
      return data.url;
    } catch (error) {
      console.error("Upload error:", error);
      throw error;
    } finally {
      setUploading(false);
    }
  };

  const validateStep = (currentStep) => {
    const newErrors = {};

    if (currentStep >= 1) {
      if (!formData.event_id) newErrors.event_id = "Selecciona un evento";
      if (!formData.title.trim()) newErrors.title = "Ingresa un título";
      if (!formData.price || formData.price <= 0)
        newErrors.price = "Ingresa un precio válido";
    }

    if (currentStep >= 2) {
      if (formData.ticket_type === "pdf" && !formData.ticket_file) {
        newErrors.ticket_file = "Sube el archivo de la entrada";
      }
      if (formData.ticket_type === "qr" && !formData.qr_code.trim()) {
        newErrors.qr_code = "Ingresa el código QR";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const prevStep = () => {
    setStep(step - 1);
  };

  const handleSubmit = async () => {
    if (!validateStep(2)) return;

    setSubmitting(true);
    try {
      let ticketFileUrl = null;

      if (formData.ticket_file) {
        ticketFileUrl = await handleFileUpload(formData.ticket_file);
      }

      const ticketData = {
        event_id: parseInt(formData.event_id),
        title: formData.title.trim(),
        description: formData.description.trim(),
        sector: formData.sector.trim() || null,
        row_number: formData.row_number.trim() || null,
        seat_number: formData.seat_number.trim() || null,
        price: parseFloat(formData.price),
        original_price: formData.original_price
          ? parseFloat(formData.original_price)
          : null,
        ticket_type: formData.ticket_type,
        ticket_file_url: ticketFileUrl,
        qr_code: formData.qr_code.trim() || null,
        is_auction: formData.is_auction,
        auto_auction: formData.auto_auction,
        auction_end_time: formData.auction_end_time || null,
      };

      const response = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(ticketData),
      });

      if (response.ok) {
        const data = await response.json();
        window.location.href = `/dashboard?success=ticket_created&id=${data.ticket.id}`;
      } else {
        const error = await response.json();
        setErrors({ general: error.error || "Error al crear la entrada" });
      }
    } catch (error) {
      console.error("Submit error:", error);
      setErrors({ general: "Error al crear la entrada" });
    } finally {
      setSubmitting(false);
    }
  };

  const selectedEvent = events.find(
    (e) => e.id === parseInt(formData.event_id),
  );

  return {
    events,
    eventsLoading,
    step,
    formData,
    errors,
    uploading,
    submitting,
    selectedEvent,
    handleInputChange,
    nextStep,
    prevStep,
    handleSubmit,
  };
}
