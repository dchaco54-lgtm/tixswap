import { useState } from "react";
import useAuth from "@/utils/useAuth";
import { Eye, EyeOff, Mail, Lock } from "lucide-react";

export default function SignInPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const { signInWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password) {
      setError("Por favor completa todos los campos");
      setLoading(false);
      return;
    }

    try {
      await signInWithCredentials({
        email,
        password,
        callbackUrl: "/",
        redirect: true,
      });
    } catch (err) {
      const errorMessages = {
        CredentialsSignin: "Email o contraseña incorrectos",
        AccessDenied: "No tienes permisos para acceder",
        CallbackRouteError: "Email o contraseña incorrectos",
      };

      setError(
        errorMessages[err.message] || "Algo salió mal. Inténtalo de nuevo.",
      );
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 sm:px-6 lg:px-8 font-inter">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex justify-center items-center space-x-3 mb-6">
            <img
              src="https://ucarecdn.com/e643de87-2123-4693-8a03-6e49f697b8ec/-/format/auto/"
              alt="TixSwap Logo"
              className="h-12 w-auto"
            />
            <h1 className="text-3xl font-bold font-poppins text-blue-600">
              TixSwap
            </h1>
          </div>
          <h2 className="text-2xl font-bold text-gray-900">
            Bienvenido de vuelta
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Inicia sesión en tu cuenta de TixSwap
          </p>
        </div>

        {/* Formulario */}
        <form
          className="space-y-6 bg-white p-8 rounded-xl shadow-sm"
          onSubmit={onSubmit}
        >
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Correo electrónico
            </label>
            <div className="relative">
              <Mail
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
              <input
                id="email"
                name="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="tu@email.com"
                required
              />
            </div>
          </div>

          {/* Contraseña */}
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Contraseña
            </label>
            <div className="relative">
              <Lock
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
              <input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* Link de recuperar contraseña */}
          <div className="text-right">
            <a
              href="/account/forgot-password"
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              ¿Olvidaste tu contraseña?
            </a>
          </div>

          {/* Botón de inicio de sesión */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Iniciando sesión..." : "Iniciar sesión"}
          </button>

          {/* Link a registro */}
          <div className="text-center">
            <span className="text-sm text-gray-600">
              ¿No tienes cuenta?{" "}
              <a
                href={`/account/signup${typeof window !== "undefined" ? window.location.search : ""}`}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                Créate una gratis
              </a>
            </span>
          </div>
        </form>

        {/* Información adicional */}
        <div className="text-center">
          <p className="text-xs text-gray-500">
            Al iniciar sesión aceptas nuestros{" "}
            <a
              href="/terms"
              className="text-blue-600 hover:text-blue-700 underline"
            >
              términos y condiciones
            </a>{" "}
            y{" "}
            <a
              href="/privacy"
              className="text-blue-600 hover:text-blue-700 underline"
            >
              política de privacidad
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
