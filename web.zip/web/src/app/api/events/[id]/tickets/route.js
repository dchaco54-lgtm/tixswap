import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id: eventId } = params;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "available";
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");
    const minPrice = parseFloat(searchParams.get("min_price"));
    const maxPrice = parseFloat(searchParams.get("max_price"));
    const sector = searchParams.get("sector");

    if (!eventId) {
      return Response.json({ error: "Event ID is required" }, { status: 400 });
    }

    // Verify event exists and is active
    const eventCheck = await sql`
      SELECT id FROM events 
      WHERE id = ${eventId} AND status = 'active'
      LIMIT 1
    `;

    if (!eventCheck || eventCheck.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    let whereConditions = ["event_id = $1"];
    let values = [eventId];
    let valueIndex = 2;

    if (status) {
      whereConditions.push(`status = $${valueIndex}`);
      values.push(status);
      valueIndex++;
    }

    if (!isNaN(minPrice)) {
      whereConditions.push(`price >= $${valueIndex}`);
      values.push(minPrice);
      valueIndex++;
    }

    if (!isNaN(maxPrice)) {
      whereConditions.push(`price <= $${valueIndex}`);
      values.push(maxPrice);
      valueIndex++;
    }

    if (sector) {
      whereConditions.push(`LOWER(sector) = LOWER($${valueIndex})`);
      values.push(sector);
      valueIndex++;
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    // Get tickets with seller information
    const query = `
      SELECT 
        t.id, t.event_id, t.seller_id, t.title, t.description, t.sector, 
        t.row_number, t.seat_number, t.price, t.original_price, t.ticket_type,
        t.ticket_file_url, t.is_auction, t.auction_end_time, t.status,
        t.validation_status, t.created_at, t.updated_at,
        u.name as seller_name, u.verified as seller_verified
      FROM tickets t
      LEFT JOIN auth_users u ON t.seller_id = u.id
      ${whereClause}
      ORDER BY t.price ASC, t.created_at DESC
      LIMIT $${valueIndex} OFFSET $${valueIndex + 1}
    `;

    values.push(limit, offset);

    const tickets = await sql(query, values);

    // Get total count for pagination
    const countQuery = `
      SELECT COUNT(*) as total 
      FROM tickets t
      ${whereClause}
    `;

    const countResult = await sql(countQuery, values.slice(0, -2));
    const total = parseInt(countResult[0]?.total || 0);

    // For auction tickets, get current highest bid
    const auctionTickets = tickets.filter((t) => t.is_auction);
    if (auctionTickets.length > 0) {
      const auctionIds = auctionTickets.map((t) => t.id);
      const bidsQuery = `
        SELECT 
          ticket_id,
          MAX(amount) as current_bid,
          COUNT(*) as bid_count
        FROM bids 
        WHERE ticket_id = ANY($1) AND status = 'active'
        GROUP BY ticket_id
      `;

      const bids = await sql(bidsQuery, [auctionIds]);

      // Update tickets with current bid info
      tickets.forEach((ticket) => {
        if (ticket.is_auction) {
          const bidInfo = bids.find((b) => b.ticket_id === ticket.id);
          ticket.current_bid = bidInfo?.current_bid || ticket.price;
          ticket.bid_count = bidInfo?.bid_count || 0;
        }
      });
    }

    return Response.json({
      tickets: tickets || [],
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    });
  } catch (err) {
    console.error("GET /api/events/[id]/tickets error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
