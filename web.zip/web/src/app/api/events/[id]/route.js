import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;

    if (!id) {
      return Response.json({ error: "Event ID is required" }, { status: 400 });
    }

    const events = await sql`
      SELECT id, title, description, venue, event_date, category, image_url, status, created_at
      FROM events 
      WHERE id = ${id} AND status = 'active'
      LIMIT 1
    `;

    if (!events || events.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    const event = events[0];

    // Get tickets count for this event
    const ticketCounts = await sql`
      SELECT 
        COUNT(*) as total_tickets,
        COUNT(CASE WHEN status = 'available' THEN 1 END) as available_tickets,
        MIN(CASE WHEN status = 'available' THEN price END) as min_price
      FROM tickets 
      WHERE event_id = ${id}
    `;

    const ticketStats = ticketCounts[0] || {
      total_tickets: 0,
      available_tickets: 0,
      min_price: null,
    };

    return Response.json({
      event: {
        ...event,
        total_tickets: parseInt(ticketStats.total_tickets),
        available_tickets: parseInt(ticketStats.available_tickets),
        min_price: ticketStats.min_price,
      },
    });
  } catch (err) {
    console.error("GET /api/events/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const {
      title,
      description,
      venue,
      event_date,
      category,
      image_url,
      status,
    } = body;

    if (!id) {
      return Response.json({ error: "Event ID is required" }, { status: 400 });
    }

    const setClauses = [];
    const values = [];

    if (title !== undefined) {
      setClauses.push("title = $" + (values.length + 1));
      values.push(title);
    }

    if (description !== undefined) {
      setClauses.push("description = $" + (values.length + 1));
      values.push(description);
    }

    if (venue !== undefined) {
      setClauses.push("venue = $" + (values.length + 1));
      values.push(venue);
    }

    if (event_date !== undefined) {
      setClauses.push("event_date = $" + (values.length + 1));
      values.push(event_date);
    }

    if (category !== undefined) {
      setClauses.push("category = $" + (values.length + 1));
      values.push(category);
    }

    if (image_url !== undefined) {
      setClauses.push("image_url = $" + (values.length + 1));
      values.push(image_url);
    }

    if (status !== undefined) {
      setClauses.push("status = $" + (values.length + 1));
      values.push(status);
    }

    if (setClauses.length === 0) {
      return Response.json(
        { error: "No valid fields to update" },
        { status: 400 },
      );
    }

    setClauses.push("updated_at = NOW()");

    const query = `
      UPDATE events 
      SET ${setClauses.join(", ")} 
      WHERE id = $${values.length + 1}
      RETURNING id, title, description, venue, event_date, category, image_url, status, created_at, updated_at
    `;

    const result = await sql(query, [...values, id]);

    if (!result || result.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    return Response.json({ event: result[0] });
  } catch (err) {
    console.error("PUT /api/events/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    if (!id) {
      return Response.json({ error: "Event ID is required" }, { status: 400 });
    }

    // Check if event has any tickets
    const ticketCount = await sql`
      SELECT COUNT(*) as count 
      FROM tickets 
      WHERE event_id = ${id}
    `;

    if (parseInt(ticketCount[0]?.count || 0) > 0) {
      return Response.json(
        { error: "Cannot delete event with existing tickets" },
        { status: 400 },
      );
    }

    const result = await sql`
      DELETE FROM events 
      WHERE id = ${id}
      RETURNING id
    `;

    if (!result || result.length === 0) {
      return Response.json({ error: "Event not found" }, { status: 404 });
    }

    return Response.json({ message: "Event deleted successfully" });
  } catch (err) {
    console.error("DELETE /api/events/[id] error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
