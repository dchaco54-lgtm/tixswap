import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import {
  Search,
  Calendar,
  MapPin,
  Star,
  Shield,
  Clock,
  Users,
} from "lucide-react";

export default function HomePage() {
  const { data: user, loading: userLoading } = useUser();
  const [events, setEvents] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  // Eventos destacados de Chile organizados por mes
  const featuredEvents = [
    // Enero
    {
      id: "mcr-enero",
      title: "My Chemical Romance",
      venue: "Estadio Bicentenario de La Florida",
      event_date: "2026-01-29T21:00:00-03:00",
      category: "Rock",
      month: "Enero",
    },
    // Febrero
    {
      id: "chayanne-feb-concepcion",
      title: "Chayanne",
      venue: "Concepción",
      event_date: "2026-02-07T21:00:00-03:00",
      category: "Pop Latino",
      month: "Febrero",
    },
    {
      id: "doja-cat-feb",
      title: "Doja Cat",
      venue: "Movistar Arena",
      event_date: "2026-02-10T21:00:00-03:00",
      category: "Hip Hop",
      month: "Febrero",
    },
    {
      id: "chayanne-feb-santiago",
      title: "Chayanne",
      venue: "Estadio Nacional de Santiago",
      event_date: "2026-02-11T21:00:00-03:00",
      category: "Pop Latino",
      month: "Febrero",
    },
    {
      id: "chayanne-feb-vina",
      title: "Chayanne",
      venue: "Viña del Mar",
      event_date: "2026-02-14T21:00:00-03:00",
      category: "Pop Latino",
      month: "Febrero",
    },
    {
      id: "jason-mraz-feb",
      title: "Jason Mraz",
      venue: "Teatro Caupolicán",
      event_date: "2026-02-25T21:00:00-03:00",
      category: "Pop",
      month: "Febrero",
    },
    {
      id: "alejandro-sanz-feb",
      title: "Alejandro Sanz",
      venue: "Movistar Arena",
      event_date: "2026-02-28T21:00:00-03:00",
      category: "Pop Latino",
      month: "Febrero",
    },
    // Marzo
    {
      id: "acdc-marzo-11",
      title: "AC/DC",
      venue: "Parque Estadio Nacional",
      event_date: "2026-03-11T21:00:00-03:00",
      category: "Rock",
      month: "Marzo",
    },
    {
      id: "lollapalooza-2026",
      title: "Lollapalooza Chile 2026",
      venue: "Parque O'Higgins",
      event_date: "2026-03-13T15:00:00-03:00",
      category: "Festival",
      month: "Marzo",
    },
    {
      id: "acdc-marzo-15",
      title: "AC/DC",
      venue: "Parque Estadio Nacional",
      event_date: "2026-03-15T21:00:00-03:00",
      category: "Rock",
      month: "Marzo",
    },
    {
      id: "soda-stereo-26",
      title: "Soda Stereo",
      venue: "Movistar Arena",
      event_date: "2026-03-26T21:00:00-03:00",
      category: "Rock Nacional",
      month: "Marzo",
    },
    {
      id: "soda-stereo-27",
      title: "Soda Stereo",
      venue: "Movistar Arena",
      event_date: "2026-03-27T21:00:00-03:00",
      category: "Rock Nacional",
      month: "Marzo",
    },
    {
      id: "soda-stereo-28",
      title: "Soda Stereo",
      venue: "Movistar Arena",
      event_date: "2026-03-28T21:00:00-03:00",
      category: "Rock Nacional",
      month: "Marzo",
    },
    // Abril
    {
      id: "ysy-a-abril",
      title: "Ysy A",
      venue: "Espacio Riesco",
      event_date: "2026-04-01T21:00:00-03:00",
      category: "Trap",
      month: "Abril",
    },
    {
      id: "respira-festival",
      title: "Respira Festival",
      venue: "Movistar Arena",
      event_date: "2026-04-03T18:00:00-03:00",
      category: "Festival",
      month: "Abril",
    },
    {
      id: "red-bull-batalla",
      title: "Red Bull Batalla - Final Internacional 2026",
      venue: "Movistar Arena",
      event_date: "2026-04-11T20:00:00-03:00",
      category: "Hip Hop",
      month: "Abril",
    },
    {
      id: "laura-pausini-15",
      title: "Laura Pausini",
      venue: "Movistar Arena",
      event_date: "2026-04-15T21:00:00-03:00",
      category: "Pop Latino",
      month: "Abril",
    },
    {
      id: "laura-pausini-16",
      title: "Laura Pausini",
      venue: "Movistar Arena",
      event_date: "2026-04-16T21:00:00-03:00",
      category: "Pop Latino",
      month: "Abril",
    },
    {
      id: "mac-demarco-18",
      title: "Mac DeMarco",
      venue: "Teatro Caupolicán",
      event_date: "2026-04-18T21:00:00-03:00",
      category: "Indie Rock",
      month: "Abril",
    },
    {
      id: "mac-demarco-19",
      title: "Mac DeMarco",
      venue: "Teatro Caupolicán",
      event_date: "2026-04-19T21:00:00-03:00",
      category: "Indie Rock",
      month: "Abril",
    },
    // Mayo
    {
      id: "pimpinela-mayo",
      title: "Pimpinela",
      venue: "Movistar Arena",
      event_date: "2026-05-17T21:00:00-03:00",
      category: "Pop Latino",
      month: "Mayo",
    },
  ];

  useEffect(() => {
    // Usar eventos predefinidos en lugar de fetch
    setEvents(featuredEvents);
    setLoading(false);
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("es-CL", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
    }).format(price);
  };

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.venue?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.category?.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  // Agrupar eventos por mes
  const eventsByMonth = filteredEvents.reduce((acc, event) => {
    if (!acc[event.month]) acc[event.month] = [];
    acc[event.month].push(event);
    return acc;
  }, {});

  const monthOrder = ["Enero", "Febrero", "Marzo", "Abril", "Mayo"];

  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Header */}
      <header className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <img
                src="https://ucarecdn.com/e643de87-2123-4693-8a03-6e49f697b8ec/-/format/auto/"
                alt="TixSwap Logo"
                className="h-10 w-auto"
              />
              <div>
                <h1 className="text-2xl font-bold font-poppins text-blue-600">
                  TixSwap
                </h1>
                <span className="text-xs text-gray-500 font-inter hidden sm:block">
                  Reventa segura, en un clic
                </span>
              </div>
            </div>

            <nav className="hidden md:flex space-x-8">
              <a
                href="#eventos"
                className="text-gray-600 hover:text-blue-600 transition-colors"
              >
                Comprar
              </a>
              <a
                href="/sell"
                className="text-gray-600 hover:text-blue-600 transition-colors"
              >
                Vender
              </a>
              <a
                href="#como-funciona"
                className="text-gray-600 hover:text-blue-600 transition-colors"
              >
                Cómo funciona
              </a>
            </nav>

            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-600">
                    Hola, {user.name}
                  </span>
                  <a
                    href="/dashboard"
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Mi Panel
                  </a>
                  <a
                    href="/account/logout"
                    className="text-gray-600 hover:text-blue-600 text-sm"
                  >
                    Salir
                  </a>
                </div>
              ) : (
                <div className="flex items-center space-x-3">
                  <a
                    href="/account/signin"
                    className="text-gray-600 hover:text-blue-600 transition-colors text-sm font-medium"
                  >
                    Iniciar sesión
                  </a>
                  <a
                    href="/account/signup"
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    Registrarse
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-blue-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold font-poppins text-gray-900 mb-6">
              Intercambia entradas
              <br />
              <span className="text-blue-600">de forma segura</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              El marketplace más confiable de Chile para comprar y vender
              entradas. Sistema de garantía, validación de tickets y pago
              protegido.
            </p>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"
                  size={20}
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Busca eventos, artistas, lugares..."
                  className="w-full pl-12 pr-4 py-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cómo funciona Section */}
      <section id="como-funciona" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            ¿Cómo funciona TixSwap?
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Pago Protegido</h3>
              <p className="text-gray-600">
                Compra con confianza. Retenemos tu dinero hasta que confirmes
                que recibiste tu entrada válida. Si hay problemas, te devolvemos
                el 100%.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">
                2. Usuarios Verificados
              </h3>
              <p className="text-gray-600">
                Sistema de calificaciones y reputación. Todos los usuarios están
                verificados con RUT chileno y teléfono validado por SMS.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Chat Integrado</h3>
              <p className="text-gray-600">
                Para entradas nominadas, chatea directamente con el vendedor
                para coordinar el cambio de nombre y entrega segura.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section id="eventos" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">
              Eventos destacados de Chile
            </h2>
            <a
              href="/events"
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              Ver todos →
            </a>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="bg-white rounded-xl shadow-sm animate-pulse"
                >
                  <div className="h-48 bg-gray-200 rounded-t-xl"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-8">
              {monthOrder.map((month) => {
                if (!eventsByMonth[month]) return null;

                return (
                  <div key={month} className="space-y-4">
                    <h3 className="text-2xl font-bold text-gray-900 border-l-4 border-blue-600 pl-4">
                      {month} 2026
                    </h3>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {eventsByMonth[month].map((event) => (
                        <div
                          key={event.id}
                          className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
                        >
                          <div className="h-48 bg-gradient-to-br from-blue-400 to-purple-500 rounded-t-xl flex items-center justify-center">
                            <span className="text-white text-lg font-semibold">
                              {event.category}
                            </span>
                          </div>
                          <div className="p-6">
                            <h4 className="text-lg font-semibold text-gray-900 mb-2">
                              {event.title}
                            </h4>
                            <div className="space-y-2 text-sm text-gray-600">
                              <div className="flex items-center">
                                <Calendar size={16} className="mr-2" />
                                {formatDate(event.event_date)}
                              </div>
                              <div className="flex items-center">
                                <MapPin size={16} className="mr-2" />
                                {event.venue}
                              </div>
                            </div>
                            <div className="mt-4 pt-4 border-t border-gray-100">
                              <a
                                href={`/events/${event.id}`}
                                className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                              >
                                Ver entradas disponibles →
                              </a>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-6">
            ¿Tienes entradas para vender?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Únete a miles de usuarios que ya confían en TixSwap para
            intercambiar sus entradas de forma segura en Chile
          </p>
          <a
            href={user ? "/sell" : "/account/signup"}
            className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-50 transition-colors inline-block"
          >
            {user ? "Publicar mis entradas" : "Comenzar ahora"}
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img
                  src="https://ucarecdn.com/e643de87-2123-4693-8a03-6e49f697b8ec/-/format/auto/"
                  alt="TixSwap Logo"
                  className="h-8 w-auto filter brightness-0 invert"
                />
                <h3 className="text-xl font-bold text-white">TixSwap</h3>
              </div>
              <p className="text-gray-400 mb-2">Reventa segura, en un clic.</p>
              <p className="text-gray-400">
                El marketplace más confiable para intercambiar entradas en
                Chile.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Plataforma</h4>
              <ul className="text-gray-400 space-y-2">
                <li>
                  <a href="#eventos" className="hover:text-white">
                    Comprar
                  </a>
                </li>
                <li>
                  <a href="/sell" className="hover:text-white">
                    Vender
                  </a>
                </li>
                <li>
                  <a href="#como-funciona" className="hover:text-white">
                    Cómo funciona
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Soporte</h4>
              <ul className="text-gray-400 space-y-2">
                <li>
                  <a href="/help" className="hover:text-white">
                    Centro de ayuda
                  </a>
                </li>
                <li>
                  <a href="/contact" className="hover:text-white">
                    Contacto
                  </a>
                </li>
                <li>
                  <a href="/disputes" className="hover:text-white">
                    Disputas
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="text-gray-400 space-y-2">
                <li>
                  <a href="/terms" className="hover:text-white">
                    Términos y condiciones
                  </a>
                </li>
                <li>
                  <a href="/privacy" className="hover:text-white">
                    Política de privacidad
                  </a>
                </li>
                <li>
                  <a href="/security" className="hover:text-white">
                    Seguridad
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2026 TixSwap. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
