import { Calendar, MapPin, DollarSign, Clock } from "lucide-react";

export function StepOne({
  formData,
  errors,
  events,
  eventsLoading,
  selectedEvent,
  handleInputChange,
  formatDate,
}) {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">
        Detalles de la entrada
      </h2>

      {/* Event Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Evento *
        </label>
        {eventsLoading ? (
          <div className="text-gray-500">Cargando eventos...</div>
        ) : (
          <select
            value={formData.event_id}
            onChange={(e) => handleInputChange("event_id", e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors.event_id ? "border-red-300" : "border-gray-300"}`}
          >
            <option value="">Selecciona un evento</option>
            {events.map((event) => (
              <option key={event.id} value={event.id}>
                {event.title} - {formatDate(event.event_date)}
              </option>
            ))}
          </select>
        )}
        {errors.event_id && (
          <p className="mt-1 text-sm text-red-600">{errors.event_id}</p>
        )}
      </div>

      {/* Selected Event Preview */}
      {selectedEvent && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-semibold text-blue-900 mb-2">
            {selectedEvent.title}
          </h3>
          <div className="flex items-center space-x-4 text-sm text-blue-700">
            <div className="flex items-center">
              <Calendar size={16} className="mr-1" />
              {formatDate(selectedEvent.event_date)}
            </div>
            <div className="flex items-center">
              <MapPin size={16} className="mr-1" />
              {selectedEvent.venue}
            </div>
          </div>
        </div>
      )}

      {/* Ticket Title */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Título de la entrada *
        </label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => handleInputChange("title", e.target.value)}
          className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors.title ? "border-red-300" : "border-gray-300"}`}
          placeholder="Ej: Entrada General - Platea Alta"
        />
        {errors.title && (
          <p className="mt-1 text-sm text-red-600">{errors.title}</p>
        )}
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Descripción
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => handleInputChange("description", e.target.value)}
          rows={3}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Describe tu entrada (ubicación específica, estado, etc.)"
        />
      </div>

      {/* Location Details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Sector
          </label>
          <input
            type="text"
            value={formData.sector}
            onChange={(e) => handleInputChange("sector", e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Campo, Platea, etc."
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fila
          </label>
          <input
            type="text"
            value={formData.row_number}
            onChange={(e) => handleInputChange("row_number", e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="A, B, 1, 2, etc."
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Asiento
          </label>
          <input
            type="text"
            value={formData.seat_number}
            onChange={(e) => handleInputChange("seat_number", e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="1, 2, 3, etc."
          />
        </div>
      </div>

      {/* Pricing */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Precio de venta *
          </label>
          <input
            type="number"
            min="0"
            step="0.01"
            value={formData.price}
            onChange={(e) => handleInputChange("price", e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors.price ? "border-red-300" : "border-gray-300"}`}
            placeholder="50000"
          />
          {errors.price && (
            <p className="mt-1 text-sm text-red-600">{errors.price}</p>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Precio original (opcional)
          </label>
          <input
            type="number"
            min="0"
            step="0.01"
            value={formData.original_price}
            onChange={(e) =>
              handleInputChange("original_price", e.target.value)
            }
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="60000"
          />
        </div>
      </div>

      {/* Sale Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Tipo de venta
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => handleInputChange("is_auction", false)}
            className={`p-4 border-2 rounded-lg text-left transition-all ${
              !formData.is_auction
                ? "border-blue-500 bg-blue-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <div className="flex items-center mb-2">
              <DollarSign size={20} className="mr-2 text-green-600" />
              <span className="font-semibold">Precio fijo</span>
            </div>
            <p className="text-sm text-gray-600">
              Vende inmediatamente al precio que estableciste
            </p>
          </button>

          <button
            type="button"
            onClick={() => handleInputChange("is_auction", true)}
            className={`p-4 border-2 rounded-lg text-left transition-all ${
              formData.is_auction
                ? "border-blue-500 bg-blue-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <div className="flex items-center mb-2">
              <Clock size={20} className="mr-2 text-orange-600" />
              <span className="font-semibold">Subasta</span>
            </div>
            <p className="text-sm text-gray-600">
              Deja que los compradores pujen por tu entrada
            </p>
          </button>
        </div>
      </div>

      {/* Auction End Time */}
      {formData.is_auction && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fecha y hora de finalización de subasta
          </label>
          <input
            type="datetime-local"
            value={formData.auction_end_time}
            onChange={(e) =>
              handleInputChange("auction_end_time", e.target.value)
            }
            min={new Date().toISOString().slice(0, 16)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      )}

      {/* Auto Auction Option */}
      {!formData.is_auction && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <input
              type="checkbox"
              id="auto_auction"
              checked={formData.auto_auction}
              onChange={(e) =>
                handleInputChange("auto_auction", e.target.checked)
              }
              className="mt-1 h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
            />
            <div className="flex-1">
              <label
                htmlFor="auto_auction"
                className="font-semibold text-orange-900 cursor-pointer"
              >
                Subasta automática de emergencia
              </label>
              <p className="text-sm text-orange-700 mt-1">
                Si mi entrada no se vende, permitir que se active
                automáticamente una subasta{" "}
                <strong>2 horas antes del evento</strong>. Los compradores
                podrán pujar y se enviará un email a cada uno cuando sea
                superado.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
