export function NavigationButtons({
  step,
  submitting,
  uploading,
  onPrev,
  onNext,
  onSubmit,
}) {
  return (
    <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
      <button
        onClick={
          step > 1 ? onPrev : () => (window.location.href = "/dashboard")
        }
        className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
      >
        {step > 1 ? "Atrás" : "Cancelar"}
      </button>

      {step < 3 ? (
        <button
          onClick={onNext}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Continuar
        </button>
      ) : (
        <button
          onClick={onSubmit}
          disabled={submitting || uploading}
          className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {submitting ? "Publicando..." : "Publicar entrada"}
        </button>
      )}
    </div>
  );
}
