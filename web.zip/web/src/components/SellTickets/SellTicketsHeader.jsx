export function SellTicketsHeader({ userName }) {
  return (
    <header className="bg-white border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <a href="/" className="flex items-center space-x-3">
              <img
                src="https://ucarecdn.com/e643de87-2123-4693-8a03-6e49f697b8ec/-/format/auto/"
                alt="TixSwap Logo"
                className="h-10 w-auto"
              />
              <div>
                <h1 className="text-2xl font-bold font-poppins text-blue-600">
                  TixSwap
                </h1>
                <span className="text-xs text-gray-500 font-inter hidden sm:block">
                  Reventa segura, en un clic
                </span>
              </div>
            </a>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">Hola, {userName}</span>
            <a
              href="/dashboard"
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
            >
              Mi Panel
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
